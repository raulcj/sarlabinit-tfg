/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.nebsyst.sarlabinit.main;

import javafx.scene.Parent;
import javafx.scene.Scene;

/**
 *
 * @author alumno
 */
public class StyleManager 
{ 
    private static StyleManager instance;
    private String cssPath;
    
    private StyleManager() { 
        // La hoja 'sarlab-main.css' es el estilo predeterminado
        cssPath = StyleManager.class.getResource("/es/styles/sarlab-main.css").toExternalForm();
    }
    
    public static StyleManager getInstance() { 
        if (instance == null) {
            instance = new StyleManager();
        }
        return instance; 
    }
     /**
     *  Aplica la hoja de estilo recibida como cadena de texto
     * 
     * @param cssSheet
     */
    public void setupCss(String cssSheet) {
        if (cssSheet.equals("Main")) {
            cssPath = StyleManager.class.getResource("/es/styles/sarlab-main.css").toExternalForm();
        } else if (cssSheet.equals("Graphite Terminal")) {
            cssPath = StyleManager.class.getResource("/es/styles/sarlab-main-lab.css").toExternalForm();
        } else if (cssSheet.equals("Glass Ocean")) {
            cssPath = StyleManager.class.getResource("/es/styles/sarlab-main-glass-ocean.css").toExternalForm();
        } else if (cssSheet.equals("Minimal State")) {
            cssPath = StyleManager.class.getResource("/es/styles/sarlab-main-minimal-slate.css").toExternalForm();
        } else if (cssSheet.equals("Violet Aurora")) {
            cssPath = StyleManager.class.getResource("/es/styles/sarlab-main-violet-aurora.css").toExternalForm();
        } else if (cssSheet.equals("Warm Terracotta")) {
            cssPath = StyleManager.class.getResource("/es/styles/sarlab-main-warm-terracotta.css").toExternalForm();
        }
    }
    /**
     *  Aplica la hoja de estilo a la Scene recibida como argumento
     * 
     * @param scene 
     */
    private void applyCss(Scene scene) {
        if (scene.getStylesheets().isEmpty()) {
            scene.getStylesheets().add(cssPath);
        }
    }

    /**
     * Devuelve un objeto Scene con el estilo aplicado
     * 
     * @param parent
     * @return Scene con estilo aplicado
     */
    public Scene createSceneCss(Parent parent) {
        Scene scene = new Scene(parent);
        applyCss(scene);
        return scene;
    }
    
}
